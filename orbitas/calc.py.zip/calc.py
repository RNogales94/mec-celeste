import numpy as np
import matplotlib.pyplot as plt

planets = np.array(["Mercurio","Venus","Tierra", "Marte","Júpiter","Saturno","Urano","Neptuno"])
epsilon = np.array([0.206,0.007,0.017,0.093,0.048,0.056,0.047,0.009])
a = np.array([0.387,0.723,1,1.524,5.203,9.546,19.2,30.09])
period = np.array([87.97,224.7,365.26,686.98,4332.6,10759,30687,60784])

# Método de Newton de Raphson
import math
import random
PI = math.pi
def newton_raphson(a, epsilon, period, t, t_ini, tolerance):
    ji = 2*PI*(t - t_ini)/period
    def phi(u):
        return (epsilon*(math.sin(u) - u*math.cos(u))+ji)/(1 - epsilon*math.cos(u))
    # Tomamos u_0 = PI
    u = PI
    phi_u = phi(u)

    while(abs(phi_u - u) > tolerance):
        u = phi_u
        phi_u = phi(u)
    return u

# Método de Newton de Bessel
import scipy.special as sp #import de las funciones especiales (como la de Bessel)

def bessel_method(a, epsilon, period, t, t_ini, tolerance):
    ji = 2*PI*(t-t_ini)/period
    def series_term(n):
        #sp.jv(n, z) es la funcion de bessel de orden n y argumento z
        return 2/n * sp.jv(n, n*epsilon)*math.sin(n*ji)

    u = ji + series_term(1)
    bessel_u = u + series_term(2)
    n = 3
    while(abs(bessel_u - u) > tolerance):
        u = bessel_u
        bessel_u = bessel_u + series_term(n)
        n = n+1

    return bessel_u

def excent2real(u,e):
    return 2*math.atan(math.sqrt((1-e)/(1+e))*math.tan(u/2))

def energy(a, p):
    mu = a**3*4*PI**2 / p**2
    return -mu/(2*a)

# calculo energia total
def energy2 (a, p, tol, e, t, ti):
    # (1/2)M vel^2
    # vel = d(position)
    vel = lambda t: (np.asarray(position(a,e, newton_raphson(a, e, p, t, ti, tol))) - np.asarray(position(a,e, newton_raphson(a, e, p, t-0.00001, ti, tol))))/0.00001
    print(vel)
    x = position(a, e, newton_raphson(a, e, p, t, ti, tol))
    print(x)
    mu = a**3*4*PI**2 / p**2
    print(mu)
    energy = (1/2)* math.sqrt(vel(t)[0]**2 + vel(t)[1]**2) - mu/math.sqrt(x[0]**2 + x[1]**2)
    return energy



def momento(t, p, a, e, mu, u):
    #myFunc = lambda x: x * 5
    u = lambda t: newton_raphson(a, e, p, t, 0, 0.00000000001)
    du = lambda t: math.sqrt(mu) / a**(3/2)*(1-e*math.cos(u(t)))
    c = a**2 * math.sqrt(1-e**2) * du(t) * (1-e*cos(u(t)))
    return c

def position(a, e, u):
    x = a*(math.cos(u) - e)
    y = a*(math.sqrt(1 - e*e)*math.sin(u))
    return [x, y]

if __name__ == "__main__":
    t_0 = 0
    tolerance = 0.00000000001

    while(True):
        planet = int(input("Elija un planeta: "))
        t = int(input("Dias desde el pericentro: "))

        anomExc_nr = newton_raphson(a[planet], epsilon[planet], period[planet], t, t_0, tolerance)
        anomExc_be = bessel_method(a[planet], epsilon[planet], period[planet], t, t_0, tolerance)
        print("Anomalía excentrica (NR): ", anomExc_nr)
        print("Anomalía excentrica (Bessel): ", anomExc_be)
        anomReal = excent2real(anomExc_nr, epsilon[planet])
        print("Anomalía real: ", anomReal)
        energ = energy(a[planet], period[planet])
        print("Energia: ", energ)
        energ2 = energy2(a[planet], period[planet], tolerance, epsilon[planet], t, t_0)
        print("Energia2: ", energ2)
        pos = position(a[planet], epsilon[planet], anomExc_nr)
        print("Posicion: ", pos)

        u = lambda t: newton_raphson(a[planet], epsilon[planet], period[planet], t, t_0, tolerance)
        pos = lambda t: position(a[planet], epsilon[planet], t)
        X = [pos(t)[0] for t in range(1000)]
        Y = [pos(t)[1] for t in range(1000)]
        #plt.scatter(X,Y)
        #plt.show()
