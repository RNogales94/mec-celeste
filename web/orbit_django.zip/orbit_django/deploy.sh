#!/bin/bash
git add .
git commit -m "deploy"
git push heroku master
heroku open
