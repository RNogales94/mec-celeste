from django.conf.urls import include, url
from django.urls import path

from django.contrib import admin
admin.autodiscover()

import orbit.views

# Examples:
# url(r'^$', 'mec_celeste.views.home', name='home'),
# url(r'^blog/', include('blog.urls')),

urlpatterns = [
    url(r'^$', orbit.views.index, name='index'),
    url(r'^api/nr',orbit.views.NR, name="newton_raphson"),
    url(r'^api/be',orbit.views.BE, name="bessel"),
    url(r'^api/position',orbit.views.position, name="position" ),
    url(r'^api/velocidad',orbit.views.velocidad, name="velocidad" ),
    url(r'^api/excent2real',orbit.views.excent2real, name="excent2real" ),
    url(r'^api/energy',orbit.views.energy, name="energy" ),
    url(r'^api/energy2',orbit.views.energy2, name="energy2" ),
    url(r'^api/coords',orbit.views.arrayPos, name="arrayPos" ),
    path('admin/', admin.site.urls),
]
