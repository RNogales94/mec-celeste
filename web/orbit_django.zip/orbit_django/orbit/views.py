from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

import json

from . import calc

# Create your views here.
def index(request):
    # return HttpResponse('orbit from Python!')
    return render(request, 'index.html')

"""
API:
    Es la interfaz que redirige las peticiones HTTP al  backend (calc.py)
    Devuelve los resultados en JSON para que el navegador lo pueda entender
"""
#   newton_raphson(a, epsilon, period, t, t_ini, tolerance):
@csrf_exempt
def NR(request):
    planet = int(request.POST.get('planet', '')) - 1
    t = int(request.POST.get('t', '0'))

    ti = 0
    tol = 0.00000001
    a = calc.a[planet]
    e = calc.epsilon[planet]
    p = calc.period[planet]

    nr = calc.newton_raphson(a, e, p, t, ti, tol)
    val_nr = json.dumps(nr)
    return HttpResponse(val_nr, content_type='application/json')


#   bessel_method(a, epsilon, period, t, t_ini, tolerance):
@csrf_exempt
def BE(request):
    planet = int(request.POST.get('planet', '')) - 1
    t = int(request.POST.get('t', '0'))
    ti = 0
    tol = 0.00000001
    a = calc.a[planet]
    e = calc.epsilon[planet]
    p = calc.period[planet]

    be = calc.bessel_method(a, e, p, t, ti, tol)
    val_be = json.dumps(be)
    return HttpResponse(val_be, content_type='application/json')

#   position(a, e, u):
@csrf_exempt
def position(request):
    planet = int(request.POST.get('planet', '')) - 1
    t = int(request.POST.get('t', ''))

    ti = 0
    tol = 0.00000001
    a = calc.a[planet]
    p = calc.period[planet]
    e = calc.epsilon[planet]
    u = calc.bessel_method(a, e, p, t, ti, tol)

    pos = calc.position(a, e, u)
    print(planet, t, pos)
    val_pos = json.dumps(pos)
    return HttpResponse(val_pos, content_type='application/json')

#   velocidad(a, e, p, u):
@csrf_exempt
def velocidad(request):
    planet = int(request.POST.get('planet', '')) - 1
    t = int(request.POST.get('t', '0'))

    ti = 0
    tol = 0.00000001
    a = calc.a[planet]
    e = calc.epsilon[planet]
    p = calc.period[planet]
    u = calc.bessel_method(a, e, p, t, ti, tol)

    vel = calc.velocidad(a, e, p, u)
    val_vel = json.dumps(vel)
    return HttpResponse(val_vel, content_type='application/json')

#   excent2real(u,e):
@csrf_exempt
def excent2real(request):
    planet = int(request.POST.get('planet', '')) - 1
    t = int(request.POST.get('t', '0'))

    ti = 0
    tol = 0.00000001
    a = calc.a[planet]
    e = calc.epsilon[planet]
    p = calc.period[planet]
    u = calc.bessel_method(a, e, p, t, ti, tol)

    val = calc.excent2real(u,e)
    json_val = json.dumps(val)
    return HttpResponse(json_val, content_type='application/json')

#   energy(a, p):
@csrf_exempt
def energy(request):

    planet = int(request.POST.get('planet', '')) - 1

    a = calc.a[planet]
    p = calc.period[planet]

    val = calc.energy(a, p)
    json_val = json.dumps(val)
    return HttpResponse(json_val, content_type='application/json')

#   energy2 (a, p, tol, e, t, ti, dos_cuerpos=False, planet=3):
@csrf_exempt
def energy2(request):
    planet = int(request.POST.get('planet', '')) - 1
    t = int(request.POST.get('t', '0'))
    dos_cuerpos = True

    ti = 0
    tol = 0.00000001
    a = calc.a[planet]
    e = calc.epsilon[planet]
    p = calc.period[planet]


    val = calc.energy2(a,p, tol, e, t, ti, dos_cuerpos, planet)
    json_val = json.dumps(val)
    return HttpResponse(json_val, content_type='application/json')


@csrf_exempt
def arrayPos(request):
    val = [[0], [0]]
    for planet in range(8):
        new_planet = calc.arrayPos(planet)
        val[0] = val[0] + new_planet[0]
        val[1] = val[1] + new_planet[1]
        json_val = json.dumps(val)
        print(json_val)
    return HttpResponse(json_val, content_type='application/json')
